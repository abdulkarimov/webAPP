package org.itstep.webapp.service;

import org.itstep.webapp.entity.Country;
import org.itstep.webapp.entity.DbItem;

import java.util.List;

public interface ItemService {
    List<DbItem> getAllItems();
    void saveItem(DbItem item);

}
