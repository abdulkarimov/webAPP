package org.itstep.webapp.service;

import org.itstep.webapp.entity.Country;
import org.itstep.webapp.entity.DbItem;
import org.itstep.webapp.repository.CtRepository;
import org.itstep.webapp.repository.itemRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class ItemServiceImpl implements ItemService {

    private final itemRepository r;

    public ItemServiceImpl(itemRepository r) {
        this.r = r;
    }


    @Override
    public List<DbItem> getAllItems() {
        return r.findAll();
    }



    @Override
    public void saveItem(DbItem item) {
        r.save(item);
    }
}
