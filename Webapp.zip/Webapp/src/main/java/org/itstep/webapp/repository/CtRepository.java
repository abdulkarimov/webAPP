package org.itstep.webapp.repository;

import org.itstep.webapp.entity.Country;
import org.itstep.webapp.entity.DbItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CtRepository extends JpaRepository<Country, Long> {

}
