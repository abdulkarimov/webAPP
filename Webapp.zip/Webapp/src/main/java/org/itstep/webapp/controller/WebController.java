package org.itstep.webapp.controller;

import lombok.extern.slf4j.Slf4j;

import org.itstep.webapp.entity.Country;
import org.itstep.webapp.entity.DbItem;
import org.itstep.webapp.service.CtService;
import org.itstep.webapp.service.ItemService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@Slf4j
public class WebController {

  private  final ItemService r;
  private  final CtService c;

  public WebController(ItemService r, CtService c) {
    this.r = r;
    this.c = c;
  }

  @GetMapping(value = "/")
  public String index(Model model) {
    List<DbItem> allitems = r.getAllItems();
    model.addAttribute("item", allitems);
    return "index";
  }

  @GetMapping(value = "/addItems")
  public String addItems(Model model)
  {
   List<Country> allCT = c.getAllCt();
   model.addAttribute("country", allCT);
    return "addItems";
  }

  @PostMapping("/addItems")
  public String addItem(
          @RequestParam(name = "name") String name,
          @RequestParam(name = "price") Integer price,
          @RequestParam(name = "amount") Integer amount,
          @RequestParam(name = "description") String description,
          @RequestParam(name = "CT") Long countryId
  ) {
    DbItem item = new DbItem();
    Country country = c.getCountryByID(countryId);
    item.setName(name);
    item.setPrice(price);
    item.setAmount(amount);
    item.setDescription(description);
    item.setCountry(country);
    r.saveItem(item);
    return "redirect:/";
  }


//  @GetMapping(value = "/login", produces = {"text/html; charset=UTF-8"})
//  public String login() {
//    return "login";
//  }
//
//  @PostMapping(value = "/login")
//  public String auth(@RequestParam(name = "email") String email, @RequestParam(name = "password") String password) {
//    log.info(email);
//    log.info(password);
//    return "redirect:/";
//  }

}
