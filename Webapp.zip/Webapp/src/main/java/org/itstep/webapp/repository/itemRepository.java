package org.itstep.webapp.repository;

import org.itstep.webapp.entity.DbItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface  itemRepository  extends JpaRepository<DbItem, Long> {

}
