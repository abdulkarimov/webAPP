package org.itstep.webapp.service;

import org.itstep.webapp.entity.Country;

import java.util.List;

public interface CtService {
    List<Country> getAllCt();
    Country getCountryByID(Long id);


}
