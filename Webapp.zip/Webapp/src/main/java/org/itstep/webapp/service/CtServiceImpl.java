package org.itstep.webapp.service;

import org.itstep.webapp.entity.Country;
import org.itstep.webapp.repository.CtRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
@Service
@Transactional
public class CtServiceImpl implements CtService {
    private final CtRepository c;

    public CtServiceImpl(CtRepository c) {
        this.c = c;
    }

    @Override
    public List<Country> getAllCt() {
        return c.findAll();
    }

    @Override
    public Country getCountryByID(Long id) {
        return c.getOne(id);
    }

}
